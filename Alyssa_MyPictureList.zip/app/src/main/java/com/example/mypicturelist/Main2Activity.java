package com.example.mypicturelist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageView imageView = (ImageView) findViewById(R.id.cityImage);
        String cityName = getIntent().getStringExtra("nameOfCity");
        switch(cityName) {
            case "vancouver":
                imageView.setImageResource(R.drawable.vancouver);
                break;
            case "edmonton":
                imageView.setImageResource(R.drawable.edmonton);
                break;
            case "montreal":
                imageView.setImageResource(R.drawable.montreal);
                break;
            case "winnipeg":
                imageView.setImageResource(R.drawable.winnipeg);
                break;
            case "toronto":
                imageView.setImageResource(R.drawable.toronto);
                break;
            default:
                // nothing
        }
    }
}
